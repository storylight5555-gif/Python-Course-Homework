BANAN WEBSITE IMAGE ASSETS

Put these files into your GitHub repository with the exact paths shown:
- banan_website/static/images/phone-product.jpg
- banan_website/static/images/phone-lifestyle.jpg
- banan_website/static/images/laptop-coming-soon.png

Then update the image src paths in templates:
- templates/index.html: phone hero -> {{ url_for('static', filename='images/phone-product.jpg') }}
- templates/shop.html: phone category -> same phone-product.jpg path
- templates/support.html: lifestyle phone -> {{ url_for('static', filename='images/phone-lifestyle.jpg') }}
- templates/onboarding.html: if keeping a background image, use phone-lifestyle.jpg as a local background URL through url_for in the style attribute, or remove the background image.

For the laptop category in templates/shop.html use:
{{ url_for('static', filename='images/laptop-coming-soon.png') }}

The first image is the main phone product image. The second image is a secondary lifestyle image. The laptop image is for the coming-soon devices section.
